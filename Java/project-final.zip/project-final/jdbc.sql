CREATE DATABASE ClassroomManagementSystem;
USE ClassroomManagementSystem;

-- Create the Student table
CREATE TABLE Student (
    ST_Number INT PRIMARY KEY NOT NULL,
    FName VARCHAR(30) NOT NULL,
    LName VARCHAR(30) NOT NULL
);

-- Create the Lecturer tabledepartmentdepartment
CREATE TABLE Lecturer (
    Lecture_ID INT PRIMARY KEY NOT NULL,
    Lecturer_fName VARCHAR(30) NOT NULL,
    Lecturer_lName VARCHAR(30) NOT NULL,
    Department VARCHAR(30) NOT NULL
);

-- Create the Gender table
CREATE TABLE Gender (
    GenderID INT PRIMARY KEY NOT NULL,
    Male VARCHAR(5) NOT NULL,
    Female VARCHAR(7) NOT NULL
);

-- Create the Classroom table
CREATE TABLE Classroom (
    Classroom_ID INT PRIMARY KEY NOT NULL,
    Location VARCHAR(20) NOT NULL,
    Date DATE NOT NULL,
    Time TIME NOT NULL,
    Lecture_ID INT
);

-- Create the Department table
CREATE TABLE Department (
    Department_ID INT PRIMARY KEY NOT NULL,
    HOD VARCHAR(30) NOT NULL,
    Department_name VARCHAR(30) NOT NULL
);

-- Create the Programme table
CREATE TABLE Programme (
    Programme_code INT PRIMARY KEY NOT NULL,
    Programme_name VARCHAR(30) NOT NULL
);

-- Add foreign keys to the Student table
ALTER TABLE Student
ADD Lecture_ID INT NOT NULL,
    Programme_code INT NOT NULL,
    GenderID INT NOT NULL;

ALTER TABLE Student
ADD FOREIGN KEY (Lecture_ID) REFERENCES Lecturer (Lecture_ID),
    FOREIGN KEY (Programme_code) REFERENCES Programme (Programme_code),
    FOREIGN KEY (GenderID) REFERENCES Gender (GenderID);

-- Add foreign keys to the Lecturer table
ALTER TABLE Lecturer
ADD ST_Number INT NOT NULL,
    Department_ID INT NOT NULL,
    Programme_code INT NOT NULL,
    GenderID INT NOT NULL;

ALTER TABLE Lecturer
ADD FOREIGN KEY (ST_Number) REFERENCES Student (ST_Number),
    FOREIGN KEY (Department_ID) REFERENCES Department (Department_ID),
    FOREIGN KEY (Programme_code) REFERENCES Programme (Programme_code),
    FOREIGN KEY (GenderID) REFERENCES Gender (GenderID);

-- Add foreign key to the Classroom table
ALTER TABLE Classroom
ADD FOREIGN KEY (Lecture_ID) REFERENCES Lecturer (Lecture_ID);

-- Add foreign keys to the Gender table
ALTER TABLE Gender
ADD ST_Number INT NOT NULL,
    Lecture_ID INT NOT NULL;

ALTER TABLE Gender
ADD FOREIGN KEY (ST_Number) REFERENCES Student (ST_Number),
    FOREIGN KEY (Lecture_ID) REFERENCES Lecturer (Lecture_ID);

-- Create the StudentRegistrationLog table
CREATE TABLE StudentRegistrationLog (
    ST_Number INT,
    RegistrationDate DATETIME
);

-- Create the StudentUpdateLog table
CREATE TABLE StudentUpdateLog (
    ST_Number INT,
    UpdateDate DATETIME
);

-- Your triggers and procedures go here...

-- INSERT statements
INSERT INTO Student (ST_Number, FName, LName) VALUES
    ('001', 'Thierry', 'Katjindi'),
    ('002', 'Esther', 'Amalovu'),
    ('003', 'Joy', 'Negumbo');

INSERT INTO Lecturer (Lecture_ID, Lecturer_fName, Lecturer_lName, Department) VALUES
    ('1', 'Helena', 'Sakaria', 'Software Development'),
    ('2', 'Sam', 'Iipumbu', 'Informatics'),
    ('3', 'Gabriella', 'Shivute', 'Cyber Security');

INSERT INTO Classroom (Classroom_ID, Location, Date, Time) VALUES
    ('A17/1/FCI Lab3', 'Office Building', '2023-09-10', '14:00:00'),
    ('K7/G/114', 'CEID', '2023-09-10', '17:15:00');

INSERT INTO Department (Department_ID, HOD, Department_name) VALUES
    ('100', 'Ms Stefanie Cloete', 'Cyber Security'),
    ('110', 'Dr Henry Mbasee', 'Software Development');

INSERT INTO Programme (Programme_code, Programme_name) VALUES
    ('07001', 'Bachelor of Computer Science'),
    ('01002', 'Bachelor of Informatics');
CREATE TRIGGER StudentRegistrationTrigger
ON Student
AFTER INSERT
AS
BEGIN
    DECLARE @RegistrationDate DATETIME
    SET @RegistrationDate = GETDATE()

    INSERT INTO StudentRegistrationLog (ST_Number, RegistrationDate)
    SELECT ST_Number, @RegistrationDate
    FROM INSERTED
END


CREATE PROCEDURE InsertStudent(
    @ST_Number INT,
    @FName VARCHAR(30),
    @LName VARCHAR(30)
)
AS
BEGIN
    INSERT INTO Student (ST_Number, FName, LName)
    VALUES (@ST_Number, @FName, @LName)
END



DECLARE StudentCursor CURSOR FOR
SELECT ST_Number, FName, LName
FROM Student

DECLARE @ST_Number INT, @FName VARCHAR(30), @LName VARCHAR(30)

OPEN StudentCursor
FETCH NEXT FROM StudentCursor INTO @ST_Number, @FName, @LName

WHILE @@FETCH_STATUS = 0
BEGIN
    -- Process the fetched data, e.g., print it
    PRINT 'Student: ST_Number = ' + CAST(@ST_Number AS VARCHAR(10)) + ', FName = ' + @FName + ', LName = ' + @LName

    FETCH NEXT FROM StudentCursor INTO @ST_Number, @FName, @LName
END

CLOSE StudentCursor
DEALLOCATE StudentCursor


CREATE TRIGGER StudentUpdateTrigger
ON Student
AFTER UPDATE
AS
BEGIN
    INSERT INTO StudentUpdateLog (ST_Number, UpdateDate)
    SELECT ST_Number, GETDATE()
    FROM INSERTED
END


CREATE TRIGGER EnforceClassroomCapacity
ON Classroom
INSTEAD OF INSERT
AS
BEGIN
    DECLARE @MaxCapacity INT = 30  -- Set your maximum capacity here

    IF (SELECT COUNT(*) + COUNT(inserted.Classroom_ID) FROM Classroom) <= @MaxCapacity
    BEGIN
        INSERT INTO Classroom (Classroom_ID, location, Date, Time)
        SELECT Classroom_ID, location, Date, Time
        FROM inserted
    END
    ELSE
    BEGIN
        RAISEERROR ('Classroom is full. Cannot insert more records.', 16, 1)
    END
END


CREATE PROCEDURE DeleteClassroomRecord(
    @Classroom_ID INT
)
AS
BEGIN
    DELETE FROM Classroom
    WHERE Classroom_ID = @Classroom_ID
END


CREATE PROCEDURE GetLecturersByDepartment(
    @DepartmentName VARCHAR(30)
)
AS
BEGIN
    SELECT Lecturer_fName, Lecturer_lName
    FROM Lecturer
    WHERE Department = @DepartmentName
END
CREATE PROCEDURE GetLecturersByProgram(
 @ProgrammeCode INT
)
AS
BEGIN
 SELECT L.Lecture_ID, L.Lecturer_fName, L.Lecturer_lName
 FROM Lecturer L
 INNER JOIN Programme P ON L.Programme_code = P.Programme_code
 WHERE P.Programme_code = @ProgrammeCode
END
CREATE PROCEDURE UpdateClassroomInfo(
 @Classroom_ID INT,
 @Location VARCHAR(20),
 @Date DATE,
 @Time TIME
)
AS
BEGIN
 UPDATE Classroom
 SET location = @Location, Date = @Date, Time = @Time
 WHERE Classroom_ID = @Classroom_ID
END
CREATE PROCEDURE GetStudentProgram(
 @ST_Number INT
)
AS
BEGIN
 SELECT P.Programme_name
 FROM Programme P
 INNER JOIN Student S ON S.Programme_code = P.Programme_code
 WHERE S.ST_Number = @ST_Number
END
CREATE PROCEDURE CountStudentsByProgram()
AS
BEGIN
 SELECT P.Programme_name, COUNT(S.ST_Number) as StudentCount
 FROM Programme P
 LEFT JOIN Student S ON P.Programme_code = S.Programme_code
 GROUP BY P.Programme_name
END
CREATE PROCEDURE AssignLecturerToDepartment(
 @Lecture_ID INT,
 @Department VARCHAR(30)
)
AS
BEGIN
 UPDATE Lecturer
 SET Department = @Department
 WHERE Lecture_ID = @Lecture_ID
END
CREATE PROCEDURE GetLecturersByClassroom(
 @Classroom_ID INT
)
AS
BEGIN
 SELECT L.Lecturer_fName, L.Lecturer_lName
 FROM Lecturer L
 INNER JOIN Classroom C ON L.Lecture_ID = C.Lecture_ID
 WHERE C.Classroom_ID = @Classroom_ID
END
CREATE PROCEDURE DeleteDepartment(
 @department_ID INT
)
AS
BEGIN
 DELETE FROM Department
 WHERE department_ID = @department_ID
END
CREATE PROCEDURE AssignStudentToProgram(
 @ST_Number INT,
 @Programme_code INT
)
AS
BEGIN
 UPDATE Student
 SET Programme_code = @Programme_code
 WHERE ST_Number = @ST_Number
END
CREATE PROCEDURE GetAllStudents()
AS
BEGIN
 SELECT ST_Number, FName, LName
 FROM Student
END
CREATE PROCEDURE GetAllLecturers()
AS
BEGIN
 SELECT Lecture_ID, Lecturer_fName, Lecturer_lName
 FROM Lecturer
END
CREATE PROCEDURE GetStudentsInClassroom(
 @Classroom_ID INT
)
AS
BEGIN
 SELECT S.ST_Number, S.FName, S.LName
 FROM Student S
 INNER JOIN Classroom C ON S.Lecture_ID = C.Lecture_ID
 WHERE C.Classroom_ID = @Classroom_ID
END
CREATE PROCEDURE DeleteProgram(
 @Programme_code INT
)
AS
BEGIN
 DELETE FROM Programme
 WHERE Programme_code = @Programme_code
END
CREATE PROCEDURE UpdateLecturerDepartment(
 @Lecture_ID INT,
 @Department VARCHAR(30)
)
AS
BEGIN
 UPDATE Lecturer
 SET Department = @Department
 WHERE Lecture_ID = @Lecture_ID
END
CREATE PROCEDURE AssignGenderToStudent(
 @ST_Number INT,
 @Male VARCHAR(5),
 @Female VARCHAR(7)
)
AS
BEGIN
 INSERT INTO Gender (ST_Number, Male, Female)
 VALUES (@ST_Number, @Male, @Female)
END
CREATE PROCEDURE DeleteGender(
 @ST_Number INT
)
AS
BEGIN
 DELETE FROM Gender
 WHERE ST_Number = @ST_Number
END
CREATE PROCEDURE GetProgramsByDepartment(
 @DepartmentName VARCHAR(30)
)
AS
BEGIN
 SELECT P.Programme_code, P.Programme_name
 FROM Programme P
 WHERE P.department_ID = (SELECT department_ID FROM Department WHERE Department_name = @DepartmentName)
END
CREATE PROCEDURE InsertLecturer(
 @Lecture_ID INT,
 @Lecturer_fName VARCHAR(30),
 @Lecturer_lName VARCHAR(30),
 @Department VARCHAR(30)
)
AS
BEGIN
 INSERT INTO Lecturer (Lecture_ID, Lecturer_fName, Lecturer_lName, Department)
 VALUES (@Lecture_ID, @Lecturer_fName, @Lecturer_lName, @Department)
END
CREATE PROCEDURE UpdateStudentInfo(
 @ST_Number INT,
 @FName VARCHAR(30),
 @LName VARCHAR(30)
)
AS
BEGIN
 UPDATE Student
 SET FName = @FName, LName = @LName
 WHERE ST_Number = @ST_Number
END
CREATE PROCEDURE DeleteStudent(
 @ST_Number INT
)
AS
BEGIN
 DELETE FROM Student
 WHERE ST_Number = @ST_Number
END
CREATE PROCEDURE DeleteLecturer(
 @Lecture_ID INT
)
AS
BEGIN
 DELETE FROM Lecturer
 WHERE Lecture_ID = @Lecture_ID
END
CREATE PROCEDURE GetClassroomInfo(
 @Classroom_ID INT
)
AS
BEGIN
 SELECT Classroom_ID, location, Date, Time
 FROM Classroom
 WHERE Classroom_ID = @Classroom_ID
END
CREATE PROCEDURE GetDepartmentInfo(
 @department_ID INT
)
AS
BEGIN
 SELECT department_ID, HOD, Department_name
 FROM Department
 WHERE department_ID = @department_ID
END
CREATE PROCEDURE GetStudentsByDepartment(
 @DepartmentName VARCHAR(30)
)
AS
BEGIN
 SELECT S.ST_Number, S.FName, S.LName
 FROM Student S
 INNER JOIN Programme P ON S.Programme_code = P.Programme_code
 INNER JOIN Department D ON P.department_ID = D.department_ID
 WHERE D.Department_name = @DepartmentName
END
CREATE PROCEDURE GetLecturerInfo(
 @Lecture_ID INT
)
AS
BEGIN
 SELECT Lecture_ID, Lecturer_fName, Lecturer_lName, Department
 FROM Lecturer
 WHERE Lecture_ID = @Lecture_ID
END
CREATE PROCEDURE AssignClassroomToLecture(
 @Classroom_ID INT,
 @Lecture_ID INT
)
AS
BEGIN
 UPDATE Classroom
 SET Lecture_ID = @Lecture_ID
 WHERE Classroom_ID = @Classroom_ID
END
CREATE PROCEDURE GetClassroomSchedule(
 @Location VARCHAR(20),
 @Date DATE,
 @Time TIME
)
AS
BEGIN
 SELECT Classroom_ID, location, Date, Time, Lecture_ID
 FROM Classroom
 WHERE location = @Location AND Date = @Date AND Time = @Time
END
CREATE PROCEDURE GetGenderBySTNumber(
 @ST_Number INT
)
AS
BEGIN
 SELECT G.Male, G.Female
 FROM Gender G
 WHERE G.ST_Number = @ST_Number
END
