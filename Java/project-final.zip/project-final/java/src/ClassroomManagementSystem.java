import java.sql.*;
import java.util.Scanner;

public class ClassroomManagementSystem {
    public static void main(String[] args) {
        String jdbcUrl = "jdbc:mysql://localhost:3306/jdbc";
        String username = "root";
        String password = "Vhur@213";
        Connection connection = null;

        try {
            connection = DriverManager.getConnection(jdbcUrl, username, password);
            System.out.println("Connected to the database");

          
            Scanner scanner = new Scanner(System.in);
            int choice;

            do {
                System.out.println("\nClassroom Management System Menu:");
                System.out.println("1. Insert a new student");
                System.out.println("2. Get students in a classroom");
                System.out.println("3. Get lecturers by department");
                System.out.println("4. Update classroom information");
                System.out.println("5. Delete a student");
                System.out.println("6. Delete a lecturer");
                System.out.println("7. Get classroom information");
                System.out.println("8. Get department information");
                System.out.println("9. Exit");
                System.out.print("Enter your choice: ");
                choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        insertStudent(connection, scanner);
                        break;
                    case 2:
                        getStudentsInClassroom(connection, scanner);
                        break;
                    case 3:
                        getLecturersByDepartment(connection, scanner);
                        break;
                    case 4:
                        updateClassroomInfo(connection, scanner);
                        break;
                    case 5:
                        deleteStudent(connection, scanner);
                        break;
                    case 6:
                        deleteLecturer(connection, scanner);
                        break;
                    case 7:
                        getClassroomInfo(connection, scanner);
                        break;
                    case 8:
                        getDepartmentInfo(connection, scanner);
                        break;
                    case 9:
                        System.out.println("Exiting...");
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } while (choice != 9);

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    

    private static void insertStudent(Connection connection, Scanner scanner) {
        try {
            
            System.out.print("Enter student ST_Number: ");
            int stNumber = scanner.nextInt();
            scanner.nextLine(); 
            System.out.print("Enter student First Name: ");
            String fName = scanner.nextLine();
            System.out.print("Enter student Last Name: ");
            String lName = scanner.nextLine();

            
            CallableStatement callableStatement = connection.prepareCall("{call InsertStudent(?, ?, ?)}");
            callableStatement.setInt(1, stNumber);
            callableStatement.setString(2, fName);
            callableStatement.setString(3, lName);
            callableStatement.execute();

            System.out.println("Student inserted successfully.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void getStudentsInClassroom(Connection connection, Scanner scanner) {
        try {
            
            System.out.print("Enter Classroom ID: ");
            String classroomId = scanner.next();

           
            CallableStatement callableStatement = connection.prepareCall("{call GetStudentsInClassroom(?)}");
            callableStatement.setString(1, classroomId);

            ResultSet resultSet = callableStatement.executeQuery();
            while (resultSet.next()) {
                int stNumber = resultSet.getInt("ST_Number");
                String fName = resultSet.getString("FName");
                String lName = resultSet.getString("LName");
                System.out.println("Student: ST_Number = " + stNumber + ", FName = " + fName + ", LName = " + lName);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void getLecturersByDepartment(Connection connection, Scanner scanner) {
        try {
            
            System.out.print("Enter Department Name: ");
            String departmentName = scanner.next();

            
            CallableStatement callableStatement = connection.prepareCall("{call GetLecturersByDepartment(?)}");
            callableStatement.setString(1, departmentName);

            ResultSet resultSet = callableStatement.executeQuery();
            while (resultSet.next()) {
                String lecturerFName = resultSet.getString("Lecturer_fName");
                String lecturerLName = resultSet.getString("Lecturer_lName");
                System.out.println("Lecturer: " + lecturerFName + " " + lecturerLName);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    private static void updateClassroomInfo(Connection connection, Scanner scanner) {
        try {
            
            System.out.print("Enter Classroom ID: ");
            int classroomId = scanner.nextInt();
            scanner.nextLine(); 
            System.out.print("Enter new Location: ");
            String location = scanner.nextLine();
            System.out.print("Enter new Date (yyyy-MM-dd): ");
            String date = scanner.nextLine();
            System.out.print("Enter new Time (HH:mm:ss): ");
            String time = scanner.nextLine();

           
            CallableStatement callableStatement = connection.prepareCall("{call UpdateClassroomInfo(?, ?, ?, ?)}");
            callableStatement.setInt(1, classroomId);
            callableStatement.setString(2, location);
            callableStatement.setDate(3, Date.valueOf(date));
            callableStatement.setTime(4, Time.valueOf(time));
            callableStatement.execute();

            System.out.println("Classroom information updated successfully.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    private static void deleteStudent(Connection connection, Scanner scanner) {
        try {
           
            System.out.print("Enter student ST_Number to delete: ");
            int stNumber = scanner.nextInt();

            // Call the DeleteStudent stored procedure
            CallableStatement callableStatement = connection.prepareCall("{call DeleteStudent(?)}");
            callableStatement.setInt(1, stNumber);
            callableStatement.execute();

            System.out.println("Student with ST_Number " + stNumber + " deleted successfully.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void deleteLecturer(Connection connection, Scanner scanner) {
        try {
           
            System.out.print("Enter lecturer Lecture_ID to delete: ");
            int lectureId = scanner.nextInt();

            // Call the DeleteLecturer stored procedure
            CallableStatement callableStatement = connection.prepareCall("{call DeleteLecturer(?)}");
            callableStatement.setInt(1, lectureId);
            callableStatement.execute();

            System.out.println("Lecturer with Lecture_ID " + lectureId + " deleted successfully.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    private static void getClassroomInfo(Connection connection, Scanner scanner) {
        try {
           
            System.out.print("Enter Classroom ID to get information: ");
            int classroomId = scanner.nextInt();

           
            CallableStatement callableStatement = connection.prepareCall("{call GetClassroomInfo(?)}");
            callableStatement.setInt(1, classroomId);
            ResultSet resultSet = callableStatement.executeQuery();

            if (resultSet.next()) {
                String location = resultSet.getString("location");
                Date date = resultSet.getDate("Date");
                Time time = resultSet.getTime("Time");

                System.out.println("Classroom ID: " + classroomId);
                System.out.println("Location: " + location);
                System.out.println("Date: " + date);
                System.out.println("Time: " + time);
            } else {
                System.out.println("Classroom not found.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void getDepartmentInfo(Connection connection, Scanner scanner) {
        try {
            
            System.out.print("Enter Department ID to get information: ");
            int departmentId = scanner.nextInt();

            CallableStatement callableStatement = connection.prepareCall("{call GetDepartmentInfo(?)}");
            callableStatement.setInt(1, departmentId);
            ResultSet resultSet = callableStatement.executeQuery();

            if (resultSet.next()) {
                String HOD = resultSet.getString("HOD");
                String departmentName = resultSet.getString("Department_name");

                System.out.println("Department ID: " + departmentId);
                System.out.println("HOD: " + HOD);
                System.out.println("Department Name: " + departmentName);
            } else {
                System.out.println("Department not found.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
